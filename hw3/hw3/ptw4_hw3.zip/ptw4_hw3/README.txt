Philip Washy
3635886

Homework 3

Included files:
main.cpp
main.h
my_gl.cpp
my_gl.h

compilation errors:
none

runtime errors:
none

comments:
translate, scale were easy to implement. scal may be tested in the program by simply hitting 's' or 'S' to scale the scene. translate is used to draw the object. rotate can be tested by holding 'y' or 'Y' ('a' and 'A' accelerate/deccelerate).
the views may be tested by un commenting each individually and recompiling and running the program. only use one view at a time.
the only aid i recieved was from the lecture notes and i used opengl.org to figure out rotation much more quickly than doing all of the multiplications by hand would have taken.